//Aluno 1: Pedro Luis de Alencar Ribeiro N° USP: 15590852
//Aluno 2: Bianca Duarte Batista Lacerda N° USP: 15443221

#include "default.h"

//esse arquivo de cabeçalho .h tem como essência definir as funções, variáveis, etc. que podem ser usadas e implementadas por utilidades.c e outros arquivos
#ifndef UTILIDADES_H
#define UTILIDADES_H

void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);

#endif